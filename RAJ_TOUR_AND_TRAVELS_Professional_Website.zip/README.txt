RAJ TOUR AND TRAVELS website files

Files:
- index.html : responsive professional website
- logo.png   : your supplied business logo

To publish on GitHub Pages:
1. Open https://github.com/raj7910/RAJTOURANDTRAVELS
2. Open the repository.
3. Upload BOTH index.html and logo.png to the repository's main/root folder.
4. If prompted, choose Commit changes.
5. Wait a few minutes, then open https://raj7910.github.io/RAJTOURANDTRAVELS/

Important:
- The booking form opens WhatsApp; it does not store customer details on a server.
- Confirm the phone numbers, email, address, service areas and prices before publishing.
